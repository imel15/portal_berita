<?php
session_start();
include 'db.php';
$type = 'frontend';
include 'navbar.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

/* ===================== LOGIKA SEARCH ===================== */
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchEsc = mysqli_real_escape_string($conn, $search);

/* ===================== FEATURED & POPULAR ===================== */
$featured = null;
$popular  = null;

if ($search == '') {
    // FEATURED
    $featuredSql = "
        SELECT a.*, k.nama AS nama_kategori
        FROM kelolaarticles a
        JOIN kategori k ON a.kategori_id = k.id
        WHERE a.status = 'published'
        ORDER BY a.created_at DESC
        LIMIT 1
    ";
    $featuredResult = mysqli_query($conn, $featuredSql);
    $featured = mysqli_fetch_assoc($featuredResult);

    // POPULAR
    $popularSql = "
        SELECT a.*, k.nama AS nama_kategori
        FROM kelolaarticles a
        JOIN kategori k ON a.kategori_id = k.id
        WHERE a.status = 'published'
        ORDER BY a.views DESC
        LIMIT 1
    ";
    $popularResult = mysqli_query($conn, $popularSql);
    $popular = mysqli_fetch_assoc($popularResult);
}

/* ===================== GRID SEMUA ARTIKEL ===================== */
$allSql = "
    SELECT a.*, k.nama AS nama_kategori
    FROM kelolaarticles a
    JOIN kategori k ON a.kategori_id = k.id
    WHERE a.status = 'published'
    " . ($search != '' ? "AND (a.title LIKE '%$searchEsc%' OR a.content LIKE '%$searchEsc%')" : "") . "
    ORDER BY a.created_at DESC
";
$allResult = mysqli_query($conn, $allSql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Portal Berita Nusantara</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<!-- HERO -->
<section class="hero">
<h1 class="fw-bold">PORTAL BERITA NUSANTARA</h1>
<p class="opacity-75">Berita aktual, terpercaya, dan terkurasi</p>
</section>

<main class="container my-5">

<?php if ($search != ''): ?>
<div class="alert alert-info text-center">
🔍 Hasil pencarian: <strong>"<?= htmlspecialchars($search) ?>"</strong>
</div>
<?php else: ?>

<!-- FEATURED & POPULAR -->
<div class="row g-4 mb-5">

<div class="col-lg-8">
<?php if ($featured): ?>
<div class="card border-0 shadow-lg text-white position-relative">
<span class="category-label"><?= $featured['nama_kategori'] ?></span>
<img src="assets/image/<?= htmlspecialchars($featured['image']) ?>" style="height:450px; object-fit:cover;">
<div class="card-img-overlay d-flex flex-column justify-content-end" style="background:linear-gradient(to top,rgba(0,0,0,.7),transparent)">
<span class="badge bg-danger mb-2">BREAKING NEWS</span>
<h3>
<a href="detailartikel.php?id=<?= $featured['id'] ?>" class="text-white text-decoration-none">
<?= htmlspecialchars($featured['title']) ?>
</a>
</h3>
</div>
</div>
<?php endif; ?>
</div>

<div class="col-lg-4">
<?php if ($popular): ?>
<div class="card border-0 shadow-lg text-white position-relative">
<span class="category-label"><?= $popular['nama_kategori'] ?></span>
<img src="assets/image/<?= htmlspecialchars($popular['image']) ?>" style="height:450px; object-fit:cover;">
<div class="card-img-overlay d-flex flex-column justify-content-end" style="background:linear-gradient(to top,rgba(0,0,0,.7),transparent)">
<span class="badge bg-danger mb-2">BERITA POPULER</span>
<h3>
<a href="detailartikel.php?id=<?= $popular['id'] ?>" class="text-white text-decoration-none">
<?= htmlspecialchars($popular['title']) ?>
</a>
</h3>
</div>
</div>
<?php endif; ?>
</div>

</div>
<?php endif; ?>

<!-- GRID -->
<div class="row g-4">
<?php if (mysqli_num_rows($allResult) > 0): ?>
<?php while($a = mysqli_fetch_assoc($allResult)): ?>
<div class="col-md-4">
<div class="card h-100 border-0 shadow-sm position-relative">
<span class="category-label"><?= $a['nama_kategori'] ?></span>
<img src="assets/image/<?= htmlspecialchars($a['image']) ?>" style="height:200px; object-fit:cover;">
<div class="card-body">
<h5>
<a href="detailartikel.php?id=<?= $a['id'] ?>" class="text-decoration-none text-dark">
<?= htmlspecialchars($a['title']) ?>
</a>
</h5>
<p class="text-muted small">
<?= substr(strip_tags($a['content']), 0, 100) ?>...
</p>
<!-- Tombol Baca Selengkapnya -->
<a href="detailartikel.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-primary mt-2">Baca Selengkapnya...</a>
</div>
</div>
</div>
<?php endwhile; ?>
<?php else: ?>
<div class="col-12">
<div class="alert alert-warning text-center">Berita tidak ditemukan</div>
</div>
<?php endif; ?>
</div>

</main>

<footer class="footer text-center py-4">
<small>&copy; 2025 Portal Berita Nusantara</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
