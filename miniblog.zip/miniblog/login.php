<?php
session_start();
include 'db.php';

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE username='$username'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user['password'])) {
            // SET SESSION
            $_SESSION['id']       = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];

            // REDIRECT BERDASARKAN ROLE
            if ($user['role'] === 'admin') {
                header("Location: dashboardadmin.php");
            } else {
                header("Location: index.php");
            }
            exit;
        } else {
            $errorMessage = "Password salah!";
        }
    } else {
        $errorMessage = "Username tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login - Portal Berita Nusantara</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
body { background:#f4f6f9; font-family:Segoe UI,sans-serif; }
.box { width:420px; margin:80px auto; background:#fff; padding:30px; border-radius:8px; box-shadow:0 8px 20px rgba(0,0,0,.1); }
.logo { text-align:center; color:#0A3A5C; font-size:32px; font-weight:bold; margin-bottom:20px; }
.subtitle { text-align:center; color:#666; margin-bottom:20px; }
.form-group { margin-bottom:15px; }
label { font-weight:600; }
input { width:100%; padding:10px; border-radius:4px; border:1px solid #ccc; }
.password-wrapper { position:relative; }
.toggle { position:absolute; right:10px; top:50%; transform:translateY(-50%); cursor:pointer; }
.btn { width:100%; padding:12px; background:#0A3A5C; color:#fff; border:none; border-radius:4px; font-weight:bold; }
.btn:hover { background:#094160; }
.error { color:red; text-align:center; margin-bottom:15px; }
.center { text-align:center; margin-top:15px; }
</style>
</head>
<body>

<div class="box">
    <div class="logo">
        <i class="bi bi-shield-check"></i> Nusantara
    </div>

    <p class="subtitle">Login Sekarang</p>

    <?php if ($errorMessage): ?>
        <div class="error"><?= $errorMessage ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required autocomplete="off">
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="password-wrapper">
                <input type="password" id="loginPassword" name="password" class="form-control" required autocomplete="new-password">
                <span class="toggle" onclick="toggle('loginPassword')">👁</span>
            </div>
        </div>

        <button type="submit" class="btn">Masuk</button>
    </form>

    <div class="center">
        Belum punya akun? <a href="register.php">Daftar</a>
    </div>
</div>

<script>
function toggle(id){
 const input = document.getElementById(id);
 input.type = input.type === 'password' ? 'text' : 'password';
}
</script>

</body>
</html>