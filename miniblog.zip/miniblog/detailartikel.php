<?php
session_start();
include 'db.php';

/* ======================
   VALIDASI ID ARTIKEL
====================== */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) die("Artikel tidak valid.");

/* ======================
   AMBIL DATA ARTIKEL
====================== */
$artikelQ = mysqli_query($conn, "SELECT * FROM kelolaarticles WHERE id=$id");
if (!$artikelQ || mysqli_num_rows($artikelQ) == 0) die("Artikel tidak ditemukan.");
$artikel = mysqli_fetch_assoc($artikelQ);

/* ======================
   TAMBAH VIEW
====================== */
mysqli_query($conn, "UPDATE kelolaarticles SET views = views + 1 WHERE id=$id");

/* ======================
   PROSES KOMENTAR / BALASAN
====================== */
if (isset($_POST['kirim_komentar'])) {
    if (!isset($_SESSION['id'])) {
        header("Location: login.php?redirect=detailartikel.php?id=$id");
        exit;
    }

    $user_id   = $_SESSION['id'];
    $komentar  = mysqli_real_escape_string($conn, trim($_POST['komentar']));
    $parent_id = isset($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

    if (!empty($komentar)) {
        mysqli_query($conn, "
            INSERT INTO komentar (artikel_id, user_id, komentar, parent_id)
            VALUES ($id, $user_id, '$komentar', " . ($parent_id ?: "NULL") . ")
        ");
        header("Location: detailartikel.php?id=$id#komentar");
        exit;
    }
}

/* ======================
   AMBIL KOMENTAR UTAMA
====================== */
$komentarQ = mysqli_query($conn, "
    SELECT k.*, u.username 
    FROM komentar k
    JOIN user u ON k.user_id = u.id
    WHERE k.artikel_id = $id AND k.parent_id IS NULL
    ORDER BY k.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($artikel['title']) ?> - Portal Berita Nusantara</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
    color: #2c3e50;
    line-height: 1.6;
}

/* ========== HEADER ========== */
header {
    background: white;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    position: sticky;
    top: 0;
    z-index: 1000;
    animation: slideDown 0.5s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

header .brand {
    font-size: 1.5rem;
    font-weight: 700;
    color: #0A3A5C;
}

header .brand i {
    color: #0A3A5C;
}

/* ========== ARTICLE ========== */
article {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.06);
    margin-bottom: 25px;
    animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

article h1 {
    font-size: 2rem;
    font-weight: 800;
    color: #0A3A5C;
    margin-bottom: 18px;
    line-height: 1.3;
}

.article-meta {
    display: flex;
    gap: 18px;
    flex-wrap: wrap;
    margin-bottom: 25px;
    padding: 12px 0;
    border-bottom: 2px solid #e9ecef;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #6c757d;
    font-size: 0.9rem;
}

.meta-item i {
    color: #0A3A5C;
}

.artikel-image {
    width: 100%;
    max-height: 400px;
    object-fit: cover;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
}

article .content {
    font-size: 1rem;
    line-height: 1.7;
    color: #2c3e50;
}

/* ========== COMMENT SECTION ========== */
#komentar {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.06);
    animation: fadeInUp 0.6s ease-out 0.2s backwards;
}

#komentar h4 {
    font-size: 1.5rem;
    font-weight: 700;
    color: #0A3A5C;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 10px;
}

#komentar h4 i {
    font-size: 1.4rem;
}

/* ========== COMMENT FORM ========== */
.comment-form {
    background: linear-gradient(135deg, rgba(10, 58, 92, 0.03), rgba(10, 58, 92, 0.01));
    border: 2px solid rgba(10, 58, 92, 0.1);
    border-radius: 12px;
    padding: 18px;
    margin-bottom: 25px;
    position: relative;
    overflow: hidden;
}

.comment-form::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 3px;
    height: 100%;
    background: linear-gradient(180deg, #0A3A5C, #094160);
}

.comment-form.disabled {
    background: linear-gradient(135deg, rgba(108, 117, 125, 0.05), rgba(108, 117, 125, 0.02));
    border-color: rgba(108, 117, 125, 0.2);
}

.comment-form textarea {
    border: 2px solid #e9ecef;
    border-radius: 10px;
    padding: 12px;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    resize: vertical;
    min-height: 80px;
}

.comment-form textarea:focus {
    border-color: #0A3A5C;
    box-shadow: 0 4px 15px rgba(10, 58, 92, 0.1);
    outline: none;
}

.comment-form textarea:disabled {
    background: #f8f9fa;
    cursor: not-allowed;
}

.comment-form button {
    background: linear-gradient(135deg, #0A3A5C, #094160);
    border: none;
    border-radius: 8px;
    padding: 10px 24px;
    font-weight: 600;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    box-shadow: 0 3px 12px rgba(10, 58, 92, 0.2);
}

.comment-form button:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 5px 18px rgba(10, 58, 92, 0.3);
}

.comment-form button:disabled {
    background: #6c757d;
    cursor: not-allowed;
}

/* ========== LOGIN WARNING ========== */
.login-warning {
    display: none;
    background: linear-gradient(135deg, rgba(255, 193, 7, 0.15), rgba(255, 193, 7, 0.05));
    border: 2px solid rgba(255, 193, 7, 0.3);
    border-radius: 10px;
    padding: 16px;
    margin-bottom: 18px;
    animation: shake 0.5s ease-in-out, fadeIn 0.3s ease-out;
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-10px); }
    75% { transform: translateX(10px); }
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.login-warning-content {
    display: flex;
    align-items: center;
    gap: 12px;
}

.login-warning-icon {
    width: 42px;
    height: 42px;
    background: #ffc107;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    color: white;
    flex-shrink: 0;
}

.login-warning-text {
    flex: 1;
}

.login-warning-text strong {
    color: #856404;
    font-size: 1rem;
    display: block;
    margin-bottom: 4px;
}

.login-warning-text p {
    margin: 0;
    color: #856404;
    font-size: 0.9rem;
}

.login-warning a {
    color: #0A3A5C;
    font-weight: 700;
    text-decoration: none;
    padding: 6px 16px;
    background: white;
    border-radius: 6px;
    display: inline-block;
    margin-top: 8px;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.login-warning a:hover {
    background: #0A3A5C;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(10, 58, 92, 0.2);
}

/* ========== COMMENT BOX ========== */
.comment-box {
    background: #f8f9fa;
    border-radius: 10px;
    padding: 16px;
    margin-bottom: 16px;
    border: 1px solid #e9ecef;
    transition: all 0.3s ease;
}

.comment-box:hover {
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transform: translateY(-2px);
}

.comment-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
}

.comment-avatar {
    width: 36px;
    height: 36px;
    background: linear-gradient(135deg, #0A3A5C, #094160);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 700;
    font-size: 1rem;
}

.comment-user {
    flex: 1;
}

.comment-user strong {
    color: #0A3A5C;
    font-size: 0.95rem;
}

.comment-user small {
    color: #6c757d;
    font-size: 0.8rem;
    display: block;
}

.comment-text {
    margin: 12px 0;
    color: #2c3e50;
    line-height: 1.6;
    font-size: 0.95rem;
}

.reply-form {
    background: white;
    border-radius: 8px;
    padding: 12px;
    margin-top: 12px;
    border: 1px solid #e9ecef;
}

.reply-form textarea {
    border: 2px solid #e9ecef;
    border-radius: 6px;
    padding: 10px;
    font-size: 0.9rem;
}

.reply-form textarea:focus {
    border-color: #0A3A5C;
    box-shadow: 0 3px 12px rgba(10, 58, 92, 0.1);
    outline: none;
}

.reply-form button {
    background: linear-gradient(135deg, #0A3A5C, #094160);
    border: none;
    border-radius: 6px;
    padding: 7px 16px;
    font-weight: 600;
    font-size: 0.85rem;
}

.reply-form button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(10, 58, 92, 0.2);
}

/* ========== REPLY BOX ========== */
.reply-box {
    margin-left: 40px;
    margin-top: 12px;
    background: white;
    border-left: 3px solid #0A3A5C;
    border-radius: 8px;
    padding: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.reply-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.reply-avatar {
    width: 28px;
    height: 28px;
    background: linear-gradient(135deg, #28a745, #20c997);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 700;
    font-size: 0.8rem;
}

.reply-user strong {
    color: #0A3A5C;
    font-size: 0.9rem;
}

.reply-user small {
    color: #6c757d;
    font-size: 0.75rem;
}

.reply-text {
    color: #2c3e50;
    line-height: 1.5;
    font-size: 0.9rem;
    margin: 0;
}

/* ========== FOOTER ========== */
footer {
    background: #0A3A5C;
    color: white;
    text-align: center;
    padding: 30px 20px;
    margin-top: 50px;
    font-weight: 500;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    article {
        padding: 20px;
    }

    article h1 {
        font-size: 1.5rem;
    }

    #komentar {
        padding: 20px;
    }

    #komentar h4 {
        font-size: 1.3rem;
    }

    .reply-box {
        margin-left: 15px;
    }

    .article-meta {
        flex-direction: column;
        gap: 8px;
    }
}
</style>
</head>

<body>

<!-- HEADER -->
<header class="py-3">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 brand">
                <i class="bi bi-shield-check"></i> Nusantara
            </div>
            <div class="col-md-6 text-end">
                <a href="index.php" class="btn btn-primary btn-sm">
                    <i class="bi bi-house-door"></i>Home
                </a>
            </div>
        </div>
    </div>
</header>

<!-- KONTEN -->
<main class="container my-5">

<article>
    <h1><?= htmlspecialchars($artikel['title']) ?></h1>
    
    <div class="article-meta">
        <div class="meta-item">
            <i class="bi bi-person-circle"></i>
            <span><?= htmlspecialchars($artikel['author']) ?></span>
        </div>
        <div class="meta-item">
            <i class="bi bi-calendar3"></i>
            <span><?= date('d F Y', strtotime($artikel['created_at'])) ?></span>
        </div>
        <div class="meta-item">
            <i class="bi bi-eye-fill"></i>
            <span><?= $artikel['views'] + 1 ?> views</span>
        </div>
    </div>

    <?php if ($artikel['image']): ?>
        <img src="assets/image/<?= htmlspecialchars($artikel['image']) ?>" class="artikel-image" alt="<?= htmlspecialchars($artikel['title']) ?>">
    <?php endif; ?>

    <div class="content"><?= nl2br(htmlspecialchars($artikel['content'])) ?></div>
</article>

<!-- KOMENTAR -->
<section id="komentar">
    <h4><i class="bi bi-chat-left-text-fill"></i> Komentar (<?= mysqli_num_rows($komentarQ) ?>)</h4>

    <!-- Login Warning (Hidden by default) -->
    <div class="login-warning" id="loginWarning">
        <div class="login-warning-content">
            <div class="login-warning-icon">
                <i class="bi bi-lock-fill"></i>
            </div>
            <div class="login-warning-text">
                <strong>Oops! Anda Belum Login</strong>
                <p>Silakan login terlebih dahulu untuk dapat berkomentar di artikel ini.</p>
                <a href="login.php?redirect=detailartikel.php?id=<?= $id ?>">
                    <i class="bi bi-box-arrow-in-right"></i> Login Sekarang
                </a>
            </div>
        </div>
    </div>

    <!-- Comment Form -->
    <form method="post" class="comment-form" id="commentForm">
        <textarea 
            name="komentar" 
            class="form-control mb-3" 
            rows="4" 
            placeholder="<?= isset($_SESSION['id']) ? 'Tulis komentar Anda...' : 'Login untuk berkomentar' ?>"
            <?= !isset($_SESSION['id']) ? 'disabled' : '' ?>
            required
        ></textarea>
        <button 
            type="submit"
            name="kirim_komentar" 
            class="btn btn-primary"
            <?= !isset($_SESSION['id']) ? 'disabled' : '' ?>
        >
            <i class="bi bi-send-fill"></i> Kirim Komentar
        </button>
    </form>

    <!-- Comment List -->
    <?php 
    mysqli_data_seek($komentarQ, 0); // Reset pointer
    while ($k = mysqli_fetch_assoc($komentarQ)): 
    ?>
    <div class="comment-box">
        <div class="comment-header">
            <div class="comment-avatar">
                <?= strtoupper(substr($k['username'], 0, 1)) ?>
            </div>
            <div class="comment-user">
                <strong><?= htmlspecialchars($k['username']) ?></strong>
                <small><?= date('d M Y, H:i', strtotime($k['created_at'])) ?></small>
            </div>
        </div>
        
        <div class="comment-text">
            <?= nl2br(htmlspecialchars($k['komentar'])) ?>
        </div>

        <!-- Reply Form -->
        <?php if (isset($_SESSION['id'])): ?>
        <form method="post" class="reply-form">
            <input type="hidden" name="parent_id" value="<?= $k['id'] ?>">
            <textarea 
                name="komentar" 
                class="form-control mb-2" 
                rows="2" 
                placeholder="Balas komentar ini..."
                required
            ></textarea>
            <button type="submit" name="kirim_komentar" class="btn btn-primary btn-sm">
                <i class="bi bi-reply-fill"></i> Balas
            </button>
        </form>
        <?php endif; ?>

        <!-- Replies -->
        <?php
        $balasanQ = mysqli_query($conn, "
            SELECT k.*, u.username 
            FROM komentar k
            JOIN user u ON k.user_id = u.id
            WHERE k.parent_id = {$k['id']}
            ORDER BY k.created_at ASC
        ");
        while ($b = mysqli_fetch_assoc($balasanQ)):
        ?>
        <div class="reply-box">
            <div class="reply-header">
                <div class="reply-avatar">
                    <?= strtoupper(substr($b['username'], 0, 1)) ?>
                </div>
                <div class="reply-user">
                    <strong><?= htmlspecialchars($b['username']) ?></strong>
                    <small><?= date('d M Y, H:i', strtotime($b['created_at'])) ?></small>
                </div>
            </div>
            <div class="reply-text">
                <?= nl2br(htmlspecialchars($b['komentar'])) ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endwhile; ?>

    <?php if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM komentar WHERE artikel_id = $id")) == 0): ?>
    <div class="text-center text-muted py-5">
        <i class="bi bi-chat-left-text" style="font-size: 3rem;"></i>
        <p class="mt-3">Belum ada komentar. Jadilah yang pertama!</p>
    </div>
    <?php endif; ?>
</section>
</main>

<footer>
    <p>&copy; 2025 Portal Berita Nusantara. Semua hak cipta dilindungi.</p>
</footer>

<script>
// Show login warning when user tries to comment without login
<?php if (!isset($_SESSION['id'])): ?>
document.getElementById('commentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const warning = document.getElementById('loginWarning');
    warning.style.display = 'block';
    warning.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    // Shake the textarea
    const textarea = this.querySelector('textarea');
    textarea.style.animation = 'shake 0.5s ease-in-out';
    setTimeout(() => {
        textarea.style.animation = '';
    }, 500);
});

// Also show warning when clicking disabled textarea
document.querySelector('.comment-form textarea').addEventListener('click', function() {
    const warning = document.getElementById('loginWarning');
    warning.style.display = 'block';
    warning.scrollIntoView({ behavior: 'smooth', block: 'center' });
});
<?php endif; ?>
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>