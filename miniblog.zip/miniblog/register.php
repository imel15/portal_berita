<?php
include 'db.php';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // AMANKAN INPUT
    $username = trim(mysqli_real_escape_string($conn, $_POST['username']));
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    if ($username === '') {
        $errorMessage = "Username tidak boleh kosong!";
    } elseif (strlen($username) < 4) {
        $errorMessage = "Username minimal 4 karakter!";
    } elseif ($password !== $confirm) {
        $errorMessage = "Konfirmasi password tidak cocok!";
    } elseif (strlen($password) < 8) {
        $errorMessage = "Password minimal 8 karakter!";
    } else {

        // CEK USERNAME
        $cek = mysqli_query($conn, "SELECT id FROM user WHERE username='$username'");
        if (mysqli_num_rows($cek) > 0) {
            $errorMessage = "Username sudah digunakan!";
        } else {

            // HASH PASSWORD
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // SIMPAN USER
            $sql = "INSERT INTO user (username, password, role)
                    VALUES ('$username', '$hash', 'user')";

            if (mysqli_query($conn, $sql)) {
                header("Location: login.php?register=success");
                exit;
            } else {
                $errorMessage = "Gagal mendaftar. Coba lagi.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Registrasi - Portal Nusantara</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
body {
    background:#f4f6f9;
    font-family:Segoe UI,sans-serif;
}
.box {
    width:420px;
    margin:80px auto;
    background:#fff;
    padding:30px;
    border-radius:8px;
    box-shadow:0 8px 20px rgba(0,0,0,.1);
}
.logo {
    text-align:center;
    color:#0A3A5C;
    font-size:32px;
    font-weight:bold;
    margin-bottom:10px;
}
.subtitle {
    text-align:center;
    color:#666;
    margin-bottom:20px;
}
.form-group {
    margin-bottom:15px;
}
.password-wrapper {
    position:relative;
}
.toggle {
    position:absolute;
    right:12px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    font-size:18px;
}
.btn {
    width:100%;
    padding:12px;
    background:#0A3A5C;
    color:#fff;
    border:none;
    border-radius:4px;
    font-weight:bold;
}
.btn:hover {
    background:#08324e;
}
.error {
    color:#dc3545;
    text-align:center;
    margin-bottom:15px;
}
.center {
    text-align:center;
    margin-top:15px;
}
</style>
</head>
<body>

<div class="box">
    <div class="logo">
        <i class="bi bi-shield-check"></i> Nusantara
    </div>

    <p class="subtitle">Buat akun baru</p>

    <?php if ($errorMessage): ?>
        <div class="error"><?= $errorMessage ?></div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
        <div class="form-group">
            <label>Username</label>
            <input type="text"
                   name="username"
                   class="form-control"
                   required
                   autocomplete="off"
                   autocapitalize="off">
        </div>

        <div class="form-group">
            <label>Password</label>
            <div class="password-wrapper">
                <input type="password"
                       id="regPass"
                       name="password"
                       class="form-control"
                       required
                       autocomplete="new-password">
                <span class="toggle" onclick="toggle('regPass')">👁</span>
            </div>
        </div>

        <div class="form-group">
            <label>Konfirmasi Password</label>
            <div class="password-wrapper">
                <input type="password"
                       id="regConfirm"
                       name="confirm_password"
                       class="form-control"
                       required
                       autocomplete="new-password">
                <span class="toggle" onclick="toggle('regConfirm')">👁</span>
            </div>
        </div>

        <button class="btn">Daftar</button>
    </form>

    <div class="center">
        Sudah punya akun? <a href="login.php">Login</a>
    </div>
</div>

<script>
function toggle(id){
    const input = document.getElementById(id);
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>

</body>
</html>
