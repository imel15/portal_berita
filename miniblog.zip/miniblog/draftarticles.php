<?php
session_start();
include 'db.php';

// untuk admin
$type = 'admin';
include 'navbar.php';

/* =====================
   PROTEKSI ADMIN
===================== */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

/* =====================
   AMBIL ARTIKEL DRAFT
===================== */
$sql = "
    SELECT a.*, k.nama AS nama_kategori
    FROM kelolaarticles a
    JOIN kategori k ON a.kategori_id = k.id
    WHERE a.status = 'draft'
    ORDER BY a.created_at DESC
";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Draft Artikel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background:#f1f3f4;
    font-family:'Segoe UI', sans-serif;
}

.card img {
    height:220px;
    object-fit:cover;
}

.category-label {
    position:absolute;
    top:10px;
    left:10px;
    background:#dc3545;
    color:white;
    padding:4px 10px;
    font-size:11px;
    border-radius:4px;
    z-index:2;
}

.navbar-nav .nav-link {
    color:#fff !important;
    font-weight:500;
}

.navbar-nav .nav-link.active {
    color:#ffd966 !important;
}
</style>
</head>

<body>

<div class="container my-4">

<h3 class="fw-bold mb-4">Draft Artikel</h3>

<div class="row g-4">

<?php if(mysqli_num_rows($result) > 0): ?>
<?php while($a = mysqli_fetch_assoc($result)): ?>
<div class="col-md-4">
    <div class="card border-0 shadow-sm h-100 position-relative">

        <span class="category-label">
            <?= htmlspecialchars($a['nama_kategori']) ?>
        </span>

        <?php if($a['image']): ?>
        <img src="assets/image/<?= htmlspecialchars($a['image']) ?>">
        <?php else: ?>
        <img src="assets/image/no-image.png">
        <?php endif; ?>

        <div class="card-body">
            <h5><?= htmlspecialchars($a['title']) ?></h5>
            <p class="text-muted small">
                <?= substr(strip_tags($a['content']), 0, 100) ?>...
            </p>
        </div>

        <div class="card-footer bg-white d-flex gap-2">
            <a href="editarticles.php?id=<?= $a['id'] ?>"
               class="btn btn-sm btn-primary">
               Edit
            </a>

            <a href="publisharticles.php?id=<?= $a['id'] ?>"
               onclick="return confirm('Publish artikel ini?')"
               class="btn btn-sm btn-success">
               Publish
            </a>

            <a href="hapusarticles.php?id=<?= $a['id'] ?>"
               onclick="return confirm('Hapus draft ini?')"
               class="btn btn-sm btn-danger">
                Hapus
            </a>
        </div>

    </div>
</div>
<?php endwhile; ?>
<?php else: ?>
<div class="col-12">
    <div class="alert alert-info text-center">
        Tidak ada artikel draft
    </div>
</div>
<?php endif; ?>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
