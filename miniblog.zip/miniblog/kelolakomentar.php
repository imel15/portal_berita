<?php
session_start();
include 'db.php';

// untuk admin
$type = 'admin';
include 'navbar.php';
/* proteksi admin */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

/* tandai semua komentar sebagai sudah dibaca */
mysqli_query($conn, "UPDATE komentar SET is_read = 1 WHERE is_read = 0");

/* PROSES BALASAN ADMIN */
if (isset($_POST['balas'])) {
    $parent_id  = (int)$_POST['parent_id'];
    $artikel_id = (int)$_POST['artikel_id'];
    $admin_id   = $_SESSION['id'];
    $balasan    = mysqli_real_escape_string($conn, $_POST['balasan']);

    mysqli_query($conn, "
        INSERT INTO komentar (artikel_id, user_id, komentar, parent_id, is_read)
        VALUES ($artikel_id, $admin_id, '$balasan', $parent_id, 1)
    ");

    header("Location: kelolakomentar.php?success=replied");
    exit;
}

/* PROSES HAPUS KOMENTAR */
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    
    // Hapus semua balasan dari komentar ini
    mysqli_query($conn, "DELETE FROM komentar WHERE parent_id = $id");
    
    // Hapus komentar utama
    mysqli_query($conn, "DELETE FROM komentar WHERE id = $id");
    
    header("Location: kelolakomentar.php?success=deleted");
    exit;
}

/* AMBIL KOMENTAR USER */
$komentar = mysqli_query($conn, "
    SELECT k.*, u.username, a.title 
    FROM komentar k
    JOIN user u ON k.user_id = u.id
    JOIN kelolaarticles a ON k.artikel_id = a.id
    WHERE k.parent_id IS NULL
    ORDER BY k.created_at DESC
");

$totalKomentar = mysqli_num_rows($komentar);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Komentar - Portal Berita Nusantara</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
    min-height: 100vh;
}

.container {
    max-width: 900px;
    margin: 30px auto;
    animation: fadeIn 0.6s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ========== PAGE HEADER ========== */
.page-header {
    background: white;
    border-radius: 12px;
    padding: 20px 25px;
    margin-bottom: 25px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.page-header h2 {
    font-size: 1.5rem;
    font-weight: 800;
    color: #0A3A5C;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.page-header h2 i {
    font-size: 1.5rem;
}

.page-header .stats {
    display: flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg, rgba(10, 58, 92, 0.1), rgba(20, 90, 141, 0.05));
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.9rem;
    color: #0A3A5C;
}

.page-header .stats i {
    font-size: 1rem;
}

/* ========== ALERTS ========== */
.alert {
    border-radius: 10px;
    padding: 12px 16px;
    margin-bottom: 20px;
    font-weight: 600;
    font-size: 0.9rem;
    animation: slideDown 0.5s ease-out;
    border: none;
}

@keyframes slideDown {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

.alert-success {
    background: linear-gradient(135deg, rgba(40, 167, 69, 0.1), rgba(40, 167, 69, 0.05));
    border: 2px solid rgba(40, 167, 69, 0.3);
    color: #155724;
}

.alert-info {
    background: linear-gradient(135deg, rgba(13, 110, 253, 0.1), rgba(13, 110, 253, 0.05));
    border: 2px solid rgba(13, 110, 253, 0.3);
    color: #084298;
}

.alert i {
    margin-right: 8px;
    font-size: 1rem;
}

/* ========== COMMENT CARD ========== */
.comment-card {
    background: white;
    border-radius: 12px;
    padding: 0;
    margin-bottom: 16px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
    overflow: hidden;
    transition: all 0.3s ease;
    animation: fadeInUp 0.6s ease-out backwards;
    border: 2px solid transparent;
}

.comment-card:nth-child(1) { animation-delay: 0.1s; }
.comment-card:nth-child(2) { animation-delay: 0.2s; }
.comment-card:nth-child(3) { animation-delay: 0.3s; }
.comment-card:nth-child(4) { animation-delay: 0.4s; }
.comment-card:nth-child(5) { animation-delay: 0.5s; }

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.comment-card:hover {
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    transform: translateY(-3px);
    border-color: rgba(10, 58, 92, 0.2);
}

/* ========== COMMENT HEADER ========== */
.comment-header {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    padding: 15px 18px;
    border-bottom: 2px solid #e9ecef;
}

.comment-user {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 10px;
}

.user-avatar {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #0A3A5C, #145A8D);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 800;
    font-size: 1.1rem;
    box-shadow: 0 3px 10px rgba(10, 58, 92, 0.3);
}

.user-info {
    flex: 1;
}

.user-info strong {
    font-size: 0.95rem;
    color: #0A3A5C;
    font-weight: 700;
}

.user-info small {
    display: block;
    color: #6c757d;
    font-size: 0.8rem;
    margin-top: 2px;
}

.article-badge {
    background: linear-gradient(135deg, rgba(10, 58, 92, 0.15), rgba(20, 90, 141, 0.1));
    color: #0A3A5C;
    padding: 6px 12px;
    border-radius: 16px;
    font-size: 0.75rem;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    border: 2px solid rgba(10, 58, 92, 0.2);
}

.article-badge i {
    font-size: 0.8rem;
}

/* ========== COMMENT BODY ========== */
.comment-body {
    padding: 18px;
}

.comment-text {
    color: #2c3e50;
    line-height: 1.6;
    font-size: 0.9rem;
    margin-bottom: 15px;
    padding: 12px;
    background: #f8f9fa;
    border-radius: 8px;
    border-left: 3px solid #0A3A5C;
}

/* ========== REPLY FORM ========== */
.reply-form {
    background: linear-gradient(135deg, rgba(10, 58, 92, 0.02), rgba(10, 58, 92, 0.01));
    padding: 15px;
    border-radius: 10px;
    border: 2px solid rgba(10, 58, 92, 0.1);
}

.reply-form label {
    font-weight: 700;
    color: #0A3A5C;
    font-size: 0.9rem;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.reply-form label i {
    font-size: 1rem;
}

.reply-form textarea {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 12px;
    font-size: 0.9rem;
    transition: all 0.3s ease;
    resize: vertical;
}

.reply-form textarea:focus {
    border-color: #0A3A5C;
    box-shadow: 0 4px 15px rgba(10, 58, 92, 0.1);
    outline: none;
}

.reply-form .form-actions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
}

/* ========== BUTTONS ========== */
.btn-reply {
    background: linear-gradient(135deg, #0A3A5C, #145A8D);
    color: white;
    border: none;
    padding: 8px 18px;
    border-radius: 8px;
    font-weight: 700;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
    box-shadow: 0 3px 12px rgba(10, 58, 92, 0.2);
}

.btn-reply:hover {
    background: linear-gradient(135deg, #145A8D, #0A3A5C);
    transform: translateY(-2px);
    box-shadow: 0 5px 18px rgba(10, 58, 92, 0.3);
    color: white;
}

.btn-delete {
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white;
    border: none;
    padding: 8px 18px;
    border-radius: 8px;
    font-weight: 700;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
    box-shadow: 0 3px 12px rgba(220, 53, 69, 0.2);
    text-decoration: none;
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c82333, #bd2130);
    transform: translateY(-2px);
    box-shadow: 0 5px 18px rgba(220, 53, 69, 0.3);
    color: white;
}

/* ========== REPLIES SECTION ========== */
.replies-section {
    margin-top: 18px;
    padding-top: 15px;
    border-top: 2px solid #e9ecef;
}

.replies-section h6 {
    font-weight: 700;
    color: #0A3A5C;
    font-size: 0.9rem;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.reply-item {
    background: #f8f9fa;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 8px;
    border-left: 3px solid #28a745;
}

.reply-author {
    font-weight: 700;
    color: #28a745;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 6px;
}

.reply-author i {
    font-size: 0.9rem;
}

.reply-text {
    color: #2c3e50;
    font-size: 0.85rem;
    line-height: 1.5;
}

/* ========== EMPTY STATE ========== */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
}

.empty-state i {
    font-size: 4rem;
    color: #dee2e6;
    margin-bottom: 15px;
}

.empty-state h4 {
    color: #6c757d;
    font-weight: 700;
    font-size: 1.1rem;
    margin-bottom: 8px;
}

.empty-state p {
    color: #adb5bd;
    font-size: 0.9rem;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .page-header h2 {
        font-size: 1.5rem;
    }

    .comment-header {
        padding: 15px;
    }

    .comment-body {
        padding: 15px;
    }

    .reply-form .form-actions {
        flex-direction: column;
    }

    .reply-form .form-actions .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>
</head>

<body>

<div class="container">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h2>
            <i class="bi bi-chat-left-text-fill"></i>
            Kelola Komentar
        </h2>
        <div class="stats">
            <i class="bi bi-chat-dots"></i>
            Total: <?= $totalKomentar ?> Komentar
        </div>
    </div>

    <!-- SUCCESS ALERTS -->
    <?php if(isset($_GET['success'])): ?>
        <?php if($_GET['success'] == 'replied'): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill"></i>
                Balasan berhasil dikirim!
            </div>
        <?php elseif($_GET['success'] == 'deleted'): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill"></i>
                Komentar berhasil dihapus!
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- EMPTY STATE -->
    <?php if ($totalKomentar == 0): ?>
        <div class="empty-state">
            <i class="bi bi-chat-left"></i>
            <h4>Belum Ada Komentar</h4>
            <p>Komentar dari pengguna akan muncul di sini</p>
        </div>
    <?php endif; ?>

    <!-- COMMENTS LIST -->
    <?php 
    mysqli_data_seek($komentar, 0);
    while ($k = mysqli_fetch_assoc($komentar)): 
    ?>
    <div class="comment-card">
        
        <!-- COMMENT HEADER -->
        <div class="comment-header">
            <div class="comment-user">
                <div class="user-avatar">
                    <?= strtoupper(substr($k['username'], 0, 1)) ?>
                </div>
                <div class="user-info">
                    <strong><?= htmlspecialchars($k['username']) ?></strong>
                    <small>
                        <i class="bi bi-clock"></i>
                        <?= date('d M Y, H:i', strtotime($k['created_at'])) ?>
                    </small>
                </div>
            </div>
            <span class="article-badge">
                <i class="bi bi-file-text"></i>
                <?= htmlspecialchars($k['title']) ?>
            </span>
        </div>

        <!-- COMMENT BODY -->
        <div class="comment-body">
            <div class="comment-text">
                <?= nl2br(htmlspecialchars($k['komentar'])) ?>
            </div>

            <!-- SHOW REPLIES IF EXISTS -->
            <?php
            $balasan = mysqli_query($conn, "
                SELECT k.*, u.username
                FROM komentar k
                JOIN user u ON k.user_id = u.id
                WHERE k.parent_id = {$k['id']}
                ORDER BY k.created_at ASC
            ");
            
            if(mysqli_num_rows($balasan) > 0):
            ?>
            <div class="replies-section">
                <h6>
                    <i class="bi bi-reply-fill"></i>
                    Balasan (<?= mysqli_num_rows($balasan) ?>)
                </h6>
                <?php while($b = mysqli_fetch_assoc($balasan)): ?>
                <div class="reply-item">
                    <div class="reply-author">
                        <i class="bi bi-shield-check"></i>
                        <?= htmlspecialchars($b['username']) ?>
                        <?php if($b['user_id'] == $_SESSION['id']): ?>
                            <span class="badge bg-success ms-2" style="font-size: 0.7rem;">Admin</span>
                        <?php endif; ?>
                        <small class="text-muted ms-auto">
                            <?= date('d M Y, H:i', strtotime($b['created_at'])) ?>
                        </small>
                    </div>
                    <div class="reply-text">
                        <?= nl2br(htmlspecialchars($b['komentar'])) ?>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>

            <!-- REPLY FORM -->
            <form method="post" class="reply-form">
                <input type="hidden" name="parent_id" value="<?= $k['id'] ?>">
                <input type="hidden" name="artikel_id" value="<?= $k['artikel_id'] ?>">

                <label>
                    <i class="bi bi-reply-fill"></i>
                    Balas Komentar
                </label>

                <textarea 
                    name="balasan"
                    class="form-control"
                    rows="3"
                    placeholder="Tulis balasan Anda di sini..."
                    required
                ></textarea>

                <div class="form-actions">
                    <button type="submit" name="balas" class="btn-reply">
                        <i class="bi bi-send-fill"></i> Kirim Balasan
                    </button>

                    <a href="kelolakomentar.php?hapus=<?= $k['id'] ?>" 
                       onclick="return confirm('Yakin ingin menghapus komentar ini? Semua balasan juga akan terhapus.')"
                       class="btn-delete">
                        <i class="bi bi-trash3"></i> Hapus Komentar
                    </a>
                </div>
            </form>

        </div>
    </div>
    <?php endwhile; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>