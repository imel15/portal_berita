<?php
session_start();
include 'db.php';

$type = 'admin';
include 'navbar.php';

// ========================
// PROTEKSI ADMIN
// ========================
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// ========================
// HAPUS USER
// ========================
if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];

    // admin tidak bisa hapus dirinya sendiri
    if ($id == $_SESSION['id']) {
        die("Tidak bisa menghapus akun sendiri.");
    }

    $deleteQuery = "DELETE FROM `user` WHERE `id`=$id";
    mysqli_query($conn, $deleteQuery);
    header("Location: kelolapengguna.php?deleted=1");
    exit;
}

// ========================
// AMBIL SEMUA USER
// ========================
$query = "SELECT * FROM `user` ORDER BY `id` DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Pengguna</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { font-family:Segoe UI; background:#f7f9fc; margin:0; padding:0; }
.container { width:90%; margin:20px auto; }
h2 { text-align:center; margin-bottom:10px; }
.success { color:green; text-align:center; margin-bottom:10px; }
.table-responsive { overflow-x:auto; }
a.adduser { display:inline-block; background:#0A3A5C; color:white; padding:8px 12px; border-radius:4px; margin-bottom:15px; text-decoration:none; }
a.adduser:hover { background:#094160; }
</style>
</head>
<body>

<div class="container">
    <h2>Kelola Pengguna</h2>

    <?php if(isset($_GET['deleted'])): ?>
    <p class="success">User berhasil dihapus!</p>
    <?php endif; ?>
    <?php if(isset($_GET['success'])): ?>
    <p class="success">User berhasil ditambahkan!</p>
    <?php endif; ?>

    <p style="text-align:center;">
        <a href="tambahuser.php" class="adduser">+ Tambah User Baru</a>
    </p>

    <div class="table-responsive">
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while($user = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= $user['role'] ?></td>
                <td><?= $user['created_at'] ?></td>
                <td>
                    <a class="btn btn-danger btn-sm" href="kelolapengguna.php?delete_id=<?= $user['id'] ?>" onclick="return confirm('Yakin hapus user ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
