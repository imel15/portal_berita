<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: /miniblog/login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: /miniblog/draftarticles.php");
    exit;
}

$id = (int) $_GET['id'];

mysqli_query($conn, "
    UPDATE kelolaarticles 
    SET status = 'published' 
    WHERE id = $id
");

header("Location: /miniblog/draftarticles.php");
exit;
