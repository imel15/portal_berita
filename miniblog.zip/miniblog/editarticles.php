<?php
session_start();
include 'db.php';

// proteksi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// ambil id artikel
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) die("ID artikel tidak valid.");

// ambil data artikel
$dataQuery = "SELECT * FROM kelolaarticles WHERE id=$id";
$result = mysqli_query($conn, $dataQuery);
if (!$result || mysqli_num_rows($result) == 0) die("Artikel tidak ditemukan.");
$data = mysqli_fetch_assoc($result);

// ambil kategori untuk sidebar
$kategori = mysqli_query($conn, "SELECT * FROM kategori");

// proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $author = $_SESSION['username'];
    $kategori_id = isset($_POST['kategori_id']) ? (int)$_POST['kategori_id'] : null;

    $gambar = $data['image'];
    if (!empty($_FILES['image']['name'])) {
        $folder = "assets/image/";
        if (!is_dir($folder)) mkdir($folder, 0777, true);
        $gambar = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $folder . $gambar);
    }

    $updateQuery = "
        UPDATE kelolaarticles 
        SET title='$title', content='$content', image='$gambar', kategori_id=".($kategori_id ?? "NULL").", author='$author'
        WHERE id=$id
    ";
    mysqli_query($conn, $updateQuery);
    header("Location: kelolaarticles.php?success=1");
    exit;
}

// set type navbar untuk admin
$type = 'admin';
include 'navbar.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Artikel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background:#f1f3f4; font-family:'Segoe UI', sans-serif; }
.editor-card, .sidebar-card { background:#fff; border-radius:10px; padding:20px; }
button { cursor:pointer; }
</style>
</head>

<script>
let timer;
function autosave() {
    clearTimeout(timer);
    timer = setTimeout(() => {
        let formData = new FormData();
        formData.append('id', <?= $id ?>);
        formData.append('title', document.getElementById('title').value);
        formData.append('content', document.getElementById('content').value);

        fetch('autosave.php', { method: 'POST', body: formData });
    }, 1500);
}
</script>

<body>
<div class="container my-4">
<form method="post" enctype="multipart/form-data">
<div class="row g-4">

<!-- EDITOR -->
<div class="col-md-8">
<div class="editor-card shadow-sm">
<input type="text" id="title" name="title" class="form-control form-control-lg mb-3" placeholder="Judul artikel..." required
       value="<?= htmlspecialchars($data['title']); ?>" oninput="autosave()">

<textarea id="content" name="content" rows="12" class="form-control" placeholder="Tulis artikel..." required
          oninput="autosave()"><?= htmlspecialchars($data['content']); ?></textarea>

<div class="d-flex gap-2 mt-3">
    <button type="submit" class="btn text-white" style="background:#003366;">💾 Update Artikel</button>
</div>
</div>
</div>

<!-- SIDEBAR -->
<div class="col-md-4">
<div class="sidebar-card shadow-sm mb-3">
<h6 class="fw-bold mb-2">Kategori</h6>
<?php while ($k = mysqli_fetch_assoc($kategori)): ?>
<div class="form-check">
    <input class="form-check-input" type="radio" name="kategori_id" value="<?= $k['id'] ?>"
        <?= $k['id'] == $data['kategori_id'] ? 'checked' : '' ?>>
    <label class="form-check-label"><?= htmlspecialchars($k['nama']); ?></label>
</div>
<?php endwhile; ?>
</div>

<div class="sidebar-card shadow-sm">
<h6 class="fw-bold mb-2">Gambar Artikel</h6>
<input type="file" name="image" class="form-control">
<?php if($data['image']): ?>
    <p>Gambar saat ini:</p>
    <img src="assets/image/<?= htmlspecialchars($data['image']); ?>" style="max-width:100%; border-radius:5px;">
<?php endif; ?>
</div>
</div>

</div>
</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
