<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$type = $type ?? 'frontend'; // Default frontend
?>

<?php if ($type === 'frontend'): ?>
    <?php include 'db.php'; ?>
    <?php $kategoriResult = mysqli_query($conn, "SELECT id, nama FROM kategori ORDER BY id ASC"); ?>
    
    <!-- Custom CSS untuk fix dropdown -->
    <style>
        header { position: relative; z-index: 1030; }
        nav.navbar { position: sticky; top: 0; z-index: 1020; }

        .dropdown-menu {
            z-index: 1040 !important;
            margin-top: 0.5rem !important;
            border: 1px solid rgba(0,0,0,.1);
            box-shadow: 0 4px 12px rgba(0,0,0,.15);
            border-radius: 8px;
            overflow: visible;
        }

        .dropdown-item:hover { background-color: #f8f9fa; }
        .position-relative { overflow: visible !important; }
        header .container { overflow: visible !important; }
    </style>
    
    <header class="bg-white shadow-sm py-3">
        <div class="container">
            <div class="row align-items-center">
                <!-- Logo / Brand -->
                <div class="col-md-4 fw-bold fs-4 text-primary">
                    <i class="bi bi-shield-check"></i> Nusantara
                </div>

                <!-- Search Form di tengah -->
                <div class="col-md-4 text-center">
                    <form method="get" class="d-flex justify-content-center">
                        <input type="text" name="search" class="form-control rounded-start-pill" 
                               placeholder="Cari berita..." 
                               value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                        <?php if(isset($id)): ?>
                            <input type="hidden" name="id" value="<?= $id ?>">
                        <?php endif; ?>
                        <button class="btn btn-primary rounded-end-pill px-3">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>

                <!-- User Login / Dropdown -->
                <div class="col-md-4 text-end">
                    <?php if(isset($_SESSION['id'])): ?>
                        <div class="dropdown d-inline-block">
                            <button class="btn btn-outline-primary btn-sm dropdown-toggle" 
                                    type="button" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-person-circle"></i>
                                <?= htmlspecialchars($_SESSION['username']) ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="userMenu">
                                <li>
                                    <a class="dropdown-item text-danger" href="logout.php">
                                        <i class="bi bi-box-arrow-right"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-box-arrow-in-right"></i> Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Navbar kategori -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background:#0A3A5C;">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="mainNav">
                <ul class="navbar-nav gap-4 text-center">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <?php while ($k = mysqli_fetch_assoc($kategoriResult)): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= ($k['id'] == ($id ?? null)) ? 'active' : '' ?>" 
                               href="kategori.php?id=<?= $k['id'] ?>">
                                <?= htmlspecialchars($k['nama']) ?>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            </div>
        </div>
    </nav>

<?php else: ?>
    <!-- NAVBAR ADMIN -->
    <style>
        nav.navbar.admin-nav { position: relative; z-index: 1000; }
    </style>
    
    <nav class="navbar navbar-expand-lg admin-nav" style="background:#003366;">
        <div class="container">
            <a class="navbar-brand fw-bold text-white" href="dashboardadmin.php">
                <i class="bi bi-newspaper"></i> Portal Berita Nusantara
            </a>
            <div class="ms-auto">
                <a href="dashboardadmin.php" class="btn btn-outline-light btn-sm me-2">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                <a href="logout.php" class="btn btn-outline-danger btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>
<?php endif; ?>
