<?php
session_start();
include 'db.php';

// untuk admin
$type = 'admin';
include 'navbar.php';


// proteksi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// ambil semua artikel + kategori
$sql = "SELECT 
            kelolaarticles.*, 
            kategori.nama AS nama_kategori
        FROM kelolaarticles
        JOIN kategori ON kelolaarticles.kategori_id = kategori.id
        ORDER BY kelolaarticles.created_at DESC";

$result = mysqli_query($conn, $sql);
$totalArticles = $result ? mysqli_num_rows($result) : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Artikel</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background:#f7f9fc;
}

.container {
    width:95%;
    margin:20px auto;
}

.add-button {
    background:#0A3A5C;
    color:white;
    padding:10px 16px;
    text-decoration:none;
    border-radius:6px;
    font-weight:500;
}

.add-button:hover {
    background:#094160;
    color:white;
}

.table thead {
    background:#0A3A5C;
    color:white;
}

.table td, .table th {
    vertical-align: middle;
    text-align:center;
}

img {
    max-width:90px;
    border-radius:6px;
}

.badge-kategori {
    background:#e3f2fd;
    color:#0A3A5C;
    font-size:13px;
    padding:6px 10px;
    border-radius:20px;
    font-weight:500;
}
</style>
</head>

<body>

<div class="table-responsive">
    <table class="table table-bordered table-striped shadow-sm bg-white align-middle text-center">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Status</th>
                <th>Gambar</th>
                <th>Penulis</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php if($totalArticles > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $row['id']; ?></td>

                <td class="text-start"><?= htmlspecialchars($row['title']); ?></td>

                <td>
                    <span class="badge bg-info text-dark rounded-pill px-2 py-1">
                        <?= htmlspecialchars($row['nama_kategori']); ?>
                    </span>
                </td>

                <td>
                    <?php if ($row['status'] === 'draft'): ?>
                        <span class="badge bg-secondary">Draft</span>
                    <?php else: ?>
                        <span class="badge bg-success">Published</span>
                    <?php endif; ?>
                </td>

                <td>
                    <?php if($row['image']): ?>
                        <img src="assets/image/<?= htmlspecialchars($row['image']); ?>" class="img-thumbnail" style="max-width:80px;">
                    <?php else: ?>
                        <small class="text-muted">Tidak ada</small>
                    <?php endif; ?>
                </td>

                <td><?= htmlspecialchars($row['author']); ?></td>

                <td><?= date('d M Y', strtotime($row['created_at'])); ?></td>

                <td>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="editarticles.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-primary">
                            Edit
                        </a>
                        <a href="hapusarticles.php?id=<?= $row['id']; ?>"
                           onclick="return confirm('Yakin hapus artikel ini?')"
                           class="btn btn-sm btn-danger">
                           Hapus
                        </a>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="8" class="text-center text-muted">
                    Belum ada artikel
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
