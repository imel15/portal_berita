<?php
session_start();
include 'db.php';

// untuk admin
$type = 'admin';
include 'navbar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

/* =====================
   AMBIL DATA KATEGORI
===================== */
$kategori = mysqli_query($conn, "SELECT * FROM kategori");

/* =====================
   SIMPAN ARTIKEL
===================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title   = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $author  = $_SESSION['username'];
    $status  = $_POST['status'] ?? 'draft';
    $kategori_id = $_POST['kategori_id'] ?? null;

    if ($status === 'published' && empty($kategori_id)) {
        die("Kategori wajib dipilih untuk publish artikel.");
    }

    $kategori_id = $kategori_id ? (int)$kategori_id : null;

    $imageName = null;
    if (!empty($_FILES['image']['name'])) {
        $folder = "assets/image/";
        if (!is_dir($folder)) mkdir($folder, 0777, true);

        $imageName = time().'_'.basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $folder.$imageName);
    }

    $sql = "INSERT INTO kelolaarticles
            (title, content, image, author, kategori_id, status)
            VALUES
            ('$title', '$content', '$imageName', '$author', ".($kategori_id ?? "NULL").", '$status')";

    mysqli_query($conn, $sql);
    header("Location: kelolaarticles.php?success=1");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Artikel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background:#f1f3f4;
    font-family:'Segoe UI', sans-serif;
}
.editor-card, .sidebar-card {
    background:#fff;
    border-radius:10px;
    padding:20px;
}
.navbar-nav .nav-link {
    color:#fff !important;
    font-weight:500;
}
.navbar-nav .nav-link.active {
    color:#ffd966 !important;
}
</style>
</head>

<script>
function submitForm(status) {
    document.getElementById('status').value = status;
    document.querySelector('form').submit();
}
</script>

<body>


<!-- KONTEN -->
<div class="container my-4">
<form method="post" enctype="multipart/form-data">

<input type="hidden" name="status" id="status">

<div class="row g-4">

<!-- EDITOR -->
<div class="col-md-8">
<div class="editor-card shadow-sm">

<input type="text"
       name="title"
       class="form-control form-control-lg mb-3"
       placeholder="Judul artikel..."
       required>

<textarea name="content"
          id="editor"
          rows="12"
          class="form-control"
          placeholder="Tulis artikel kamu di sini..."
          required></textarea>

<div class="d-flex gap-2 mt-3">
<button type="button"
        class="btn btn-outline-secondary"
        onclick="submitForm('draft')">
💾 Simpan Draft
</button>

<button type="button"
        class="btn text-white"
        style="background:#003366;"
        onclick="submitForm('published')">
🚀 Publikasikan
</button>
</div>

</div>
</div>

<!-- SIDEBAR -->
<div class="col-md-4">

<div class="sidebar-card shadow-sm mb-3">
<h6 class="fw-bold mb-2">Kategori</h6>
<?php while ($k = mysqli_fetch_assoc($kategori)): ?>
<div class="form-check">
<input class="form-check-input"
       type="radio"
       name="kategori_id"
       value="<?= $k['id']; ?>">
<label class="form-check-label">
<?= htmlspecialchars($k['nama']); ?>
</label>
</div>
<?php endwhile; ?>
</div>

<div class="sidebar-card shadow-sm">
<h6 class="fw-bold mb-2">Gambar Artikel</h6>
<input type="file" name="image" class="form-control">
</div>

</div>

</div>
</form>
</div>

<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
ClassicEditor.create(document.querySelector('#editor'));
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
