<?php
session_start();
include 'db.php';

// Tentukan tipe navbar admin
$type = 'admin';
include 'navbar.php';

// Proteksi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Proses tambah user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $sql = "INSERT INTO `user` (`username`, `password`, `role`) 
            VALUES ('$username', '$password', '$role')";

    if (!mysqli_query($conn, $sql)) {
        die("Tambah user gagal: " . mysqli_error($conn));
    }

    header("Location: kelolapengguna.php?success=1");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah User</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family:Segoe UI; background:#f7f9fc; }
.container-form { max-width:600px; margin:30px auto; background:white; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
button { background:#0A3A5C; color:white; padding:10px 15px; border:none; border-radius:4px; cursor:pointer; }
button:hover { background:#094160; }
</style>
</head>
<body>

<div class="container my-4">

  <div class="container-form">
    <h2 class="mb-3">Tambah User Baru</h2>
    <form method="post">
        <label>Username</label>
        <input type="text" name="username" class="form-control mb-2" required>

        <label>Password</label>
        <input type="password" name="password" class="form-control mb-2" required>

        <label>Role</label>
        <select name="role" class="form-control mb-3" required>
            <option value="user">User</option>
            <option value="admin">Admin</option>
        </select>

        <button type="submit">Simpan User</button>
    </form>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
