<?php
session_start();
include 'db.php';

/* ======================
   PROTEKSI ADMIN
====================== */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

/* ======================
   DATA STATISTIK
====================== */

// total artikel
$qArtikel = mysqli_query($conn, "
    SELECT COUNT(*) AS total 
    FROM kelolaarticles
");
$totalArtikel = mysqli_fetch_assoc($qArtikel)['total'];

// artikel publish
$qPublish = mysqli_query($conn, "
    SELECT COUNT(*) AS total 
    FROM kelolaarticles 
    WHERE status = 'published'
");
$totalPublish = mysqli_fetch_assoc($qPublish)['total'];

// artikel draft
$qDraft = mysqli_query($conn, "
    SELECT COUNT(*) AS total 
    FROM kelolaarticles 
    WHERE status = 'draft'
");
$totalDraft = mysqli_fetch_assoc($qDraft)['total'];

// total komentar
$qKomentar = mysqli_query($conn, "
    SELECT COUNT(*) AS total 
    FROM komentar
");
$totalKomentar = mysqli_fetch_assoc($qKomentar)['total'];

// komentar baru
$qNotif = mysqli_query($conn, "
    SELECT COUNT(*) AS total 
    FROM komentar 
    WHERE is_read = 0
");
$komentarBaru = mysqli_fetch_assoc($qNotif)['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin - Portal Berita Nusantara</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%);
    display: flex;
    margin: 0;
    min-height: 100vh;
}

/* ========== SIDEBAR ========== */
.sidebar {
    width: 280px;
    background: linear-gradient(180deg, #0A3A5C 0%, #094160 100%);
    color: white;
    min-height: 100vh;
    padding: 0;
    box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
    position: fixed;
    z-index: 1000;
    overflow-y: auto;
}

.sidebar-header {
    padding: 30px 20px;
    text-align: center;
    background: rgba(255, 255, 255, 0.05);
    border-bottom: 2px solid rgba(255, 255, 255, 0.1);
}

.sidebar-header h2 {
    font-size: 1.5rem;
    font-weight: 700;
    margin: 0;
    background: linear-gradient(135deg, #ffffff 0%, #e0e0e0 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.sidebar-header p {
    font-size: 0.75rem;
    margin: 5px 0 0 0;
    opacity: 0.7;
    font-weight: 400;
}

.sidebar-menu {
    padding: 20px;
}

.sidebar a {
    color: rgba(255, 255, 255, 0.85);
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    border-radius: 10px;
    margin-bottom: 8px;
    transition: all 0.3s ease;
    font-weight: 500;
    font-size: 0.95rem;
    position: relative;
    overflow: hidden;
}

.sidebar a::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: white;
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar a:hover {
    background: rgba(255, 255, 255, 0.15);
    color: white;
    transform: translateX(5px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.sidebar a:hover::before {
    transform: scaleY(1);
}

.sidebar a.active {
    background: white;
    color: #0A3A5C;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(255, 255, 255, 0.2);
}

.sidebar a.active i {
    color: #0A3A5C;
}

.sidebar a i {
    font-size: 1.2rem;
    width: 24px;
    text-align: center;
}

.sidebar a.logout-btn {
    margin-top: 20px;
    background: rgba(220, 53, 69, 0.1);
    border: 1px solid rgba(220, 53, 69, 0.3);
    color: #ff6b6b;
}

.sidebar a.logout-btn:hover {
    background: rgba(220, 53, 69, 0.2);
    color: #ff4757;
}

/* ========== CONTENT AREA ========== */
.content {
    flex: 1;
    margin-left: 280px;
    padding: 30px;
    width: calc(100% - 280px);
}

/* ========== TOP NAVBAR ========== */
.top-navbar {
    background: white;
    border-radius: 16px;
    padding: 20px 30px;
    margin-bottom: 30px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
    display: flex;
    justify-content: space-between;
    align-items: center;
    animation: slideDown 0.5s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.top-navbar .brand {
    font-size: 1.4rem;
    font-weight: 700;
    color: #0A3A5C;
    display: flex;
    align-items: center;
    gap: 10px;
}

.top-navbar .brand i {
    font-size: 1.6rem;
}

.top-navbar .user-section {
    display: flex;
    align-items: center;
    gap: 20px;
}

.notification-btn {
    position: relative;
    background: #f8f9fa;
    border: none;
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    color: #495057;
}

.notification-btn:hover {
    background: #0A3A5C;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(10, 58, 92, 0.2);
}

.notification-btn i {
    font-size: 1.3rem;
}

.notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: linear-gradient(135deg, #dc3545, #c82333);
    color: white;
    font-size: 0.7rem;
    font-weight: 700;
    padding: 3px 7px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(220, 53, 69, 0.4);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.1);
    }
}

.user-info {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 18px;
    background: linear-gradient(135deg, #0A3A5C 0%, #094160 100%);
    border-radius: 12px;
    color: white;
    font-weight: 600;
}

.user-info i {
    font-size: 1.5rem;
}

/* ========== STAT CARDS ========== */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    border-radius: 14px;
    padding: 22px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    animation: fadeInUp 0.6s ease-out backwards;
    cursor: pointer;
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }
.stat-card:nth-child(4) { animation-delay: 0.4s; }

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #0A3A5C, #094160);
}

.stat-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.12);
}

.stat-card:active {
    transform: translateY(-4px) scale(1.01);
}

.stat-card.primary::before {
    background: linear-gradient(90deg, #0A3A5C, #094160);
}

.stat-card.success::before {
    background: linear-gradient(90deg, #28a745, #20c997);
}

.stat-card.secondary::before {
    background: linear-gradient(90deg, #6c757d, #495057);
}

.stat-card.danger::before {
    background: linear-gradient(90deg, #dc3545, #c82333);
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin-bottom: 12px;
}

.stat-card.primary .stat-icon {
    background: linear-gradient(135deg, rgba(10, 58, 92, 0.15), rgba(30, 90, 122, 0.08));
    color: #0A3A5C;
}

.stat-card.success .stat-icon {
    background: linear-gradient(135deg, rgba(40, 167, 69, 0.15), rgba(52, 208, 88, 0.08));
    color: #28a745;
}

.stat-card.secondary .stat-icon {
    background: linear-gradient(135deg, rgba(108, 117, 125, 0.15), rgba(134, 142, 150, 0.08));
    color: #6c757d;
}

.stat-card.danger .stat-icon {
    background: linear-gradient(135deg, rgba(220, 53, 69, 0.15), rgba(255, 71, 87, 0.08));
    color: #dc3545;
}

.stat-label {
    font-size: 0.85rem;
    color: #6c757d;
    font-weight: 500;
    margin-bottom: 6px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-value {
    font-size: 2rem;
    font-weight: 800;
    margin: 0;
    line-height: 1;
}

.stat-card.primary .stat-value {
    color: #0A3A5C;
}

.stat-card.success .stat-value {
    color: #28a745;
}

.stat-card.secondary .stat-value {
    color: #6c757d;
}

.stat-card.danger .stat-value {
    color: #dc3545;
}

.stat-change {
    font-size: 0.8rem;
    margin-top: 10px;
    display: flex;
    align-items: center;
    gap: 5px;
    color: #6c757d;
}

.stat-change.positive {
    color: #28a745;
}

.stat-change.negative {
    color: #dc3545;
}

/* ========== RESPONSIVE ========== */
@media (max-width: 992px) {
    .sidebar {
        width: 250px;
    }
    
    .content {
        margin-left: 250px;
        width: calc(100% - 250px);
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 0;
        transform: translateX(-100%);
        transition: transform 0.3s ease;
    }
    
    .sidebar.active {
        width: 280px;
        transform: translateX(0);
    }
    
    .content {
        margin-left: 0;
        width: 100%;
        padding: 20px;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .top-navbar {
        flex-direction: column;
        gap: 15px;
        padding: 20px;
    }
    
    .top-navbar .brand {
        font-size: 1.2rem;
    }
}

/* Scrollbar Styling */
.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.3);
}
</style>
</head>

<body>

<!-- ========== SIDEBAR ========== -->
<div class="sidebar">
    <div class="sidebar-header">
        <h2><i class="bi bi-newspaper"></i> Admin Panel</h2>
        <p>Portal Berita Nusantara</p>
    </div>

    <div class="sidebar-menu">
        <a href="dashboardadmin.php" class="active">
            <i class="bi bi-speedometer2"></i>
            <span>Dashboard</span>
        </a>

        <a href="tambaharticles.php">
            <i class="bi bi-plus-circle"></i>
            <span>Tambah Postingan</span>
        </a>

        <a href="kelolaarticles.php">
            <i class="bi bi-newspaper"></i>
            <span>Kelola Artikel</span>
        </a>

        <a href="draftarticles.php">
            <i class="bi bi-file-earmark-text"></i>
            <span>Draft Postingan</span>
        </a>

        <a href="kelolakomentar.php">
            <i class="bi bi-chat-left-text"></i>
            <span>Kelola Komentar</span>
        </a>

        <a href="kelolapengguna.php">
            <i class="bi bi-people"></i>
            <span>Kelola User</span>
        </a>

        <a href="logout.php" class="logout-btn">
            <i class="bi bi-box-arrow-right"></i>
            <span>Logout</span>
        </a>
    </div>
</div>

<!-- ========== CONTENT ========== -->
<div class="content">

    <!-- Top Navbar -->
    <div class="top-navbar">
        <div class="brand">
            <i class="bi bi-grid-fill"></i>
            Dashboard Overview
        </div>

        <div class="user-section">
            <a href="kelolakomentar.php" class="notification-btn">
                <i class="bi bi-bell"></i>
                <?php if ($komentarBaru > 0): ?>
                    <span class="notification-badge"><?= $komentarBaru ?></span>
                <?php endif; ?>
            </a>

            <div class="user-info">
                <i class="bi bi-person-circle"></i>
                <span><?= htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <a href="kelolaarticles.php" class="stat-card primary" style="text-decoration: none; color: inherit;">
            <div class="stat-icon">
                <i class="bi bi-file-text"></i>
            </div>
            <div class="stat-label">Total Artikel</div>
            <h2 class="stat-value"><?= $totalArtikel ?></h2>
            <div class="stat-change positive">
                <i class="bi bi-arrow-up"></i>
                Semua artikel
            </div>
        </a>

        <a href="index.php" class="stat-card success" style="text-decoration: none; color: inherit;">
            <div class="stat-icon">
                <i class="bi bi-check-circle"></i>
            </div>
            <div class="stat-label">Artikel Publish</div>
            <h2 class="stat-value"><?= $totalPublish ?></h2>
            <div class="stat-change positive">
                <i class="bi bi-arrow-up"></i>
                Sudah dipublikasikan
            </div>
        </a>

        <a href="draftarticles.php" class="stat-card secondary" style="text-decoration: none; color: inherit;">
            <div class="stat-icon">
                <i class="bi bi-file-earmark"></i>
            </div>
            <div class="stat-label">Artikel Draft</div>
            <h2 class="stat-value"><?= $totalDraft ?></h2>
            <div class="stat-change">
                <i class="bi bi-dash"></i>
                Belum dipublikasikan
            </div>
        </a>

        <a href="kelolakomentar.php" class="stat-card danger" style="text-decoration: none; color: inherit;">
            <div class="stat-icon">
                <i class="bi bi-chat-dots"></i>
            </div>
            <div class="stat-label">Komentar Baru</div>
            <h2 class="stat-value"><?= $komentarBaru ?></h2>
            <div class="stat-change <?= $komentarBaru > 0 ? 'positive' : '' ?>">
                <i class="bi bi-<?= $komentarBaru > 0 ? 'arrow-up' : 'dash' ?>"></i>
                <?= $komentarBaru > 0 ? 'Perlu ditinjau' : 'Tidak ada' ?>
            </div>
        </a>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>