<?php
session_start();
include 'db.php';

// Set tipe navbar untuk frontend
$type = 'frontend';

/* =====================
   AMBIL KATEGORI NAVBAR
===================== */
$kategoriResult = mysqli_query($conn, "SELECT id, nama FROM kategori ORDER BY id ASC");

// Ambil ID kategori
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    echo "Kategori tidak ditemukan";
    exit;
}

$kategoriRes = mysqli_query($conn, "SELECT nama FROM kategori WHERE id=$id LIMIT 1");
$kategori = mysqli_fetch_assoc($kategoriRes);
if (!$kategori) {
    echo "Kategori tidak ditemukan";
    exit;
}

// Ambil search jika ada
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchEsc = mysqli_real_escape_string($conn, $search);

/* =====================
   FEATURED ARTICLE KATEGORI
===================== */
$featuredSql = "
    SELECT a.*, k.nama AS nama_kategori
    FROM kelolaarticles a
    JOIN kategori k ON a.kategori_id = k.id
    WHERE k.id=$id
    " . ($search!='' ? " AND (a.title LIKE '%$searchEsc%' OR a.content LIKE '%$searchEsc%')" : "") . "
    ORDER BY a.created_at DESC
    LIMIT 1
";
$featuredResult = mysqli_query($conn, $featuredSql);
$featured = mysqli_fetch_assoc($featuredResult);

/* =====================
   GRID ARTIKEL KATEGORI (Kecil di samping featured)
===================== */
$gridSql = "
    SELECT a.*, k.nama AS nama_kategori
    FROM kelolaarticles a
    JOIN kategori k ON a.kategori_id = k.id
    WHERE k.id=$id
    " . ($search!='' ? " AND (a.title LIKE '%$searchEsc%' OR a.content LIKE '%$searchEsc%')" : "") . "
    ORDER BY a.created_at DESC
    LIMIT 1,6
";
$gridResult = mysqli_query($conn, $gridSql);

/* =====================
   SEMUA ARTIKEL KATEGORI (GRID UTAMA)
===================== */
$allSql = "
    SELECT a.*, k.nama AS nama_kategori
    FROM kelolaarticles a
    JOIN kategori k ON a.kategori_id = k.id
    WHERE k.id=$id
    " . ($search!='' ? " AND (a.title LIKE '%$searchEsc%' OR a.content LIKE '%$searchEsc%')" : "") . "
    ORDER BY a.created_at DESC
";
$allResult = mysqli_query($conn, $allSql);

// Sertakan navbar
include 'navbar.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Portal Berita Nusantara - <?= htmlspecialchars($kategori['nama']) ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<style>
body { background: #f5f7fb; }
.hero {
    background: linear-gradient(120deg, #0A3A5C, #145A8D);
    color: white;
    padding: 70px 0;
    text-align: center;
}
.card img { transition: .3s; }
.card:hover img { transform: scale(1.05); }
.card { transition: transform .2s; }
.card:hover { transform: translateY(-5px); }

.category-label {
    position: absolute;
    top: 12px;
    left: 12px;
    background: #dc3545;
    color: white;
    padding: 5px 12px;
    font-size: 11px;
    font-weight: 600;
    border-radius: 4px;
    text-transform: uppercase;
    z-index: 2;
}

.footer {
    background-color: #0A3A5C;
    color: white;
}
</style>
</head>
<body>

<!-- HERO KATEGORI -->
<section class="hero">
<h1 class="fw-bold"><?= htmlspecialchars($kategori['nama']) ?></h1>
<p class="opacity-75">Berita terkini di kategori <?= htmlspecialchars($kategori['nama']) ?></p>
</section>

<main class="container my-5">

<!-- FEATURED -->
<?php if ($featured): ?>
<div class="row g-4 mb-5">
<div class="col-lg-8">
<div class="card border-0 shadow-lg text-white position-relative">
<span class="category-label"><?= $featured['nama_kategori'] ?></span>
<img src="assets/image/<?= htmlspecialchars($featured['image']) ?>" style="height:450px; object-fit:cover;">
<div class="card-img-overlay d-flex flex-column justify-content-end"
style="background:linear-gradient(to top,rgba(0,0,0,.7),transparent)">
<span class="badge bg-danger mb-2">FEATURED</span>
<h3>
<a href="detailartikel.php?id=<?= $featured['id'] ?>" class="text-white text-decoration-none">
<?= htmlspecialchars($featured['title']) ?>
</a>
</h3>
</div>
</div>
</div>

<div class="col-lg-4">
<?php while($g = mysqli_fetch_assoc($gridResult)): ?>
<div class="card mb-3 shadow-sm border-0 position-relative">
<span class="category-label"><?= $g['nama_kategori'] ?></span>
<img src="assets/image/<?= htmlspecialchars($g['image']) ?>" style="height:160px; object-fit:cover;">
<div class="card-body">
<h6>
<a href="detailartikel.php?id=<?= $g['id'] ?>" class="text-decoration-none text-dark">
<?= htmlspecialchars($g['title']) ?>
</a>
</h6>
<!-- Tombol Baca Selengkapnya -->
<a href="detailartikel.php?id=<?= $g['id'] ?>" class="btn btn-sm btn-primary mt-2">Baca Selengkapnya...</a>
</div>
</div>
<?php endwhile; ?>
</div>
</div>
<?php endif; ?>

<!-- GRID SEMUA ARTIKEL -->
<div class="row g-4">
<?php if(mysqli_num_rows($allResult) > 0): ?>
<?php while($a = mysqli_fetch_assoc($allResult)): ?>
<div class="col-md-4">
<div class="card h-100 border-0 shadow-sm position-relative">
<span class="category-label"><?= $a['nama_kategori'] ?></span>
<img src="assets/image/<?= htmlspecialchars($a['image']) ?>" style="height:200px; object-fit:cover;">
<div class="card-body">
<h5>
<a href="detailartikel.php?id=<?= $a['id'] ?>" class="text-decoration-none text-dark">
<?= htmlspecialchars($a['title']) ?>
</a>
</h5>
<p class="text-muted small"><?= substr(strip_tags($a['content']),0,100) ?>...</p>
<!-- Tombol Baca Selengkapnya -->
<a href="detailartikel.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-primary mt-2">Baca Selengkapnya...</a>
</div>
</div>
</div>
<?php endwhile; ?>
<?php else: ?>
<div class="col-12">
<div class="alert alert-warning text-center">Tidak ada berita di kategori ini</div>
</div>
<?php endif; ?>
</div>

</main>

<footer class="footer text-center py-4">
<small>&copy; 2025 Portal Berita Nusantara</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
