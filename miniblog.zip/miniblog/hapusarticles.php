<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: dashboardadmin.php");
    exit;
}

$id = (int) $_GET['id'];

// hapus komentar dulu (jika ada)
mysqli_query($conn, "DELETE FROM komentar WHERE artikel_id = $id");

// hapus artikel
mysqli_query($conn, "DELETE FROM kelolaarticles WHERE id = $id");

header("Location: dashboardadmin.php?deleted=1");
exit;
