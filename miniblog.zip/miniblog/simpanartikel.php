<?php
session_start();
include 'db.php';

// proteksi admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $author = $_SESSION['username'];

    // upload gambar ke folder assets/image
    $gambar = '';
    if (!empty($_FILES['gambar']['name'])) {
        $folder = "assets/image/";
        if (!is_dir($folder)) mkdir($folder, 0777, true);

        $gambar = time() . '_' . basename($_FILES['gambar']['name']);
        if (!move_uploaded_file($_FILES['gambar']['tmp_name'], $folder . $gambar)) {
            die("Gagal mengupload gambar.");
        }
    }

    $sql = "INSERT INTO kelolaarticles (title, content, image, author) 
            VALUES ('$title', '$content', '$gambar', '$author')";
    mysqli_query($conn, $sql);

    header("Location: kelolaarticles.php?success=1");
    exit;
}
?>
